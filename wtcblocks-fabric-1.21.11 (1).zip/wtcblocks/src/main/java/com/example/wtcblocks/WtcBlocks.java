package com.example.wtcblocks;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.command.CommandManager;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class WtcBlocks implements ModInitializer {
    public static final String MOD_ID = "wtcblocks";
    private static final List<Block> ALL = new ArrayList<>();

    public static final Block FACADE_PANEL    = register("facade_panel", 5f);
    public static final Block WINDOW_PANEL    = register("window_panel", 3f);
    public static final Block CORNER_COLUMN   = register("corner_column", 6f);
    public static final Block LOBBY_COLUMN    = register("lobby_column", 6f);
    public static final Block MECHANICAL_BAND = register("mechanical_band", 5f);
    public static final Block ROOF_BLOCK      = register("roof_block", 5f);

    private static Block register(String name, float hardness) {
        Identifier id = Identifier.of(MOD_ID, name);
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, id);
        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, id);

        Block block = new Block(AbstractBlock.Settings.create()
                .registryKey(blockKey)
                .strength(hardness, 10f)
                .sounds(BlockSoundGroup.METAL)
                .requiresTool());
        Registry.register(Registries.BLOCK, blockKey, block);

        BlockItem item = new BlockItem(block, new Item.Settings()
                .registryKey(itemKey)
                .useBlockPrefixedTranslationKey());
        Registry.register(Registries.ITEM, itemKey, item);

        ALL.add(block);
        return block;
    }

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM_GROUP, Identifier.of(MOD_ID, "main"),
            FabricItemGroup.builder()
                .displayName(Text.translatable("itemGroup.wtcblocks.main"))
                .icon(() -> new ItemStack(FACADE_PANEL))
                .entries((ctx, entries) -> ALL.forEach(entries::add))
                .build());

        // /buildwtc : строит башни-близнецы вокруг игрока (масштаб 1:2).
        // Для серверов добавьте .requires(...) с проверкой прав оператора.
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("buildwtc").executes(ctx -> {
                var source = ctx.getSource();
                BlockPos origin = BlockPos.ofFloored(source.getPosition());
                int placed = WtcBuilder.build(source.getWorld(), origin);
                if (placed < 0) {
                    source.sendError(Text.literal("Слишком мало места по высоте — выберите место пониже."));
                    return 0;
                }
                source.sendFeedback(() -> Text.literal("World Trade Center построен: " + placed + " блоков."), true);
                return 1;
            })));
    }
}
