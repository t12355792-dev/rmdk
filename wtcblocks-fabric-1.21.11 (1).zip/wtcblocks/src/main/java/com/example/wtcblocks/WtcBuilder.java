package com.example.wtcblocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

/** Строит две башни 32x32 (скошенные углы), высота до 220 блоков (110 этажей по 2 блока). */
public final class WtcBuilder {
    private static final int S = 32;
    private static final int FLOORS = 110;
    private static final int CENTER_OFFSET = 27; // зазор между башнями ~22 блока
    private static final int ANTENNA = 36;

    private WtcBuilder() {}

    private static boolean inside(int x, int z) {
        if (x < 0 || z < 0 || x >= S || z >= S) return false;
        return Math.min(x, S - 1 - x) + Math.min(z, S - 1 - z) >= 3;
    }

    private static boolean perimeter(int x, int z) {
        return inside(x, z) && !(inside(x + 1, z) && inside(x - 1, z) && inside(x, z + 1) && inside(x, z - 1));
    }

    private static boolean corner(int x, int z) {
        return Math.min(x, S - 1 - x) <= 3 && Math.min(z, S - 1 - z) <= 3;
    }

    private static boolean band(int f) {
        return f == 6 || f == 7 || f == 40 || f == 41 || f == 74 || f == 75 || f == 107 || f == 108;
    }

    private static boolean bandFloorRow(int h) {
        int f = h / 2;
        return h % 2 == 0 && (f == 6 || f == 40 || f == 74 || f == 107);
    }

    /** @return число поставленных блоков, либо -1 если не хватает высоты */
    public static int build(ServerWorld world, BlockPos origin) {
        int topExclusive = world.getBottomY() + world.getHeight();
        int height = Math.min(FLOORS * 2, topExclusive - origin.getY() - 3);
        if (height < 12) return -1;

        int count = 0;
        count += tower(world, origin.getX() - CENTER_OFFSET - S / 2, origin.getZ() - S / 2, origin.getY(), height, true);
        count += tower(world, origin.getX() + CENTER_OFFSET - S / 2, origin.getZ() - S / 2, origin.getY(), height, false);
        return count;
    }

    private static int tower(ServerWorld world, int x0, int z0, int y0, int height, boolean antenna) {
        int n = 0;
        for (int x = 0; x < S; x++) {
            for (int z = 0; z < S; z++) {
                if (!inside(x, z)) continue;
                boolean per = perimeter(x, z);

                n += set(world, x0 + x, y0 - 1, z0 + z, Blocks.QUARTZ_BLOCK.getDefaultState());

                for (int h = 0; h < height; h++) {
                    BlockState st = null;
                    if (per) {
                        st = pick(x, z, h);
                    } else if (bandFloorRow(h)) {
                        st = WtcBlocks.ROOF_BLOCK.getDefaultState();
                    }
                    if (st != null) n += set(world, x0 + x, y0 + h, z0 + z, st);
                }
                n += set(world, x0 + x, y0 + height, z0 + z, WtcBlocks.ROOF_BLOCK.getDefaultState());
                if (per) n += set(world, x0 + x, y0 + height + 1, z0 + z, WtcBlocks.ROOF_BLOCK.getDefaultState());
            }
        }
        if (antenna && y0 + height + 2 + ANTENNA < world.getBottomY() + world.getHeight()) {
            for (int a = 0; a < ANTENNA; a++) {
                n += set(world, x0 + S / 2, y0 + height + 2 + a, z0 + S / 2, Blocks.IRON_BARS.getDefaultState());
            }
        }
        return n;
    }

    private static BlockState pick(int x, int z, int h) {
        Block b;
        if (corner(x, z)) b = WtcBlocks.CORNER_COLUMN;
        else if (h < 8) b = ((x + z) % 2 == 0) ? WtcBlocks.LOBBY_COLUMN : WtcBlocks.WINDOW_PANEL;
        else if (band(h / 2)) b = WtcBlocks.MECHANICAL_BAND;
        else b = (h % 2 == 0) ? WtcBlocks.FACADE_PANEL : WtcBlocks.WINDOW_PANEL;
        return b.getDefaultState();
    }

    private static int set(ServerWorld world, int x, int y, int z, BlockState state) {
        world.setBlockState(new BlockPos(x, y, z), state, Block.NOTIFY_LISTENERS);
        return 1;
    }
}
