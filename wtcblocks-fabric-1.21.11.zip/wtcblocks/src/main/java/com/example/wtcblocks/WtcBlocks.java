package com.example.wtcblocks;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.command.CommandManager;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class WtcBlocks implements ModInitializer {
    public static final String MOD_ID = "wtcblocks";
    private static final List<Block> ALL = new ArrayList<>();

    private static final BlockSoundGroup M = BlockSoundGroup.METAL;
    private static final BlockSoundGroup ST = BlockSoundGroup.STONE;
    private static final BlockSoundGroup GL = BlockSoundGroup.GLASS;
    private static final BlockSoundGroup WD = BlockSoundGroup.WOOD;

    // --- основные ---
    public static final Block FACADE_PANEL     = cube("facade_panel", 5f, 0, M);
    public static final Block WINDOW_PANEL     = cube("window_panel", 3f, 0, GL);
    public static final Block CORNER_COLUMN    = cube("corner_column", 6f, 0, M);
    public static final Block LOBBY_COLUMN     = cube("lobby_column", 6f, 0, M);
    public static final Block MECHANICAL_BAND  = cube("mechanical_band", 5f, 0, M);
    public static final Block ROOF_BLOCK       = cube("roof_block", 5f, 0, M);
    // --- новые ---
    public static final Block FACADE_PANEL_DARK  = cube("facade_panel_dark", 5f, 0, M);
    public static final Block FACADE_PANEL_LIGHT = cube("facade_panel_light", 5f, 0, M);
    public static final Block STEEL_BEAM       = cube("steel_beam", 6f, 0, M);
    public static final Block STEEL_PLATE      = cube("steel_plate", 6f, 0, M);
    public static final Block DARK_STEEL       = cube("dark_steel", 6f, 0, M);
    public static final Block MIRROR_GLASS     = cube("mirror_glass", 3f, 0, GL);
    public static final Block SKY_LOBBY_WINDOW = cube("sky_lobby_window", 3f, 0, GL);
    public static final Block TRIDENT_COLUMN   = cube("trident_column", 6f, 0, ST);
    public static final Block MARBLE           = cube("marble", 3f, 0, ST);
    public static final Block DARK_MARBLE      = cube("dark_marble", 3f, 0, ST);
    public static final Block CONCRETE_FLOOR   = cube("concrete_floor", 3f, 0, ST);
    public static final Block CEILING_TILE     = cube("ceiling_tile", 2f, 0, ST);
    public static final Block ELEVATOR_DOOR    = cube("elevator_door", 5f, 0, M);
    public static final Block OFFICE_LIGHT     = cube("office_light", 2f, 15, GL);
    public static final Block OBSERVATION_FLOOR = cube("observation_floor", 3f, 0, WD);
    public static final Block ANTENNA_SEGMENT  = cube("antenna_segment", 5f, 0, M);
    public static final Block ANTENNA_BEACON   = cube("antenna_beacon", 5f, 15, GL);
    public static final Block PLAZA_GRANITE    = cube("plaza_granite", 4f, 0, ST);
    public static final Block BRONZE_SPHERE_BLOCK = cube("bronze_sphere_block", 6f, 0, M);
    // --- ступени и плиты ---
    public static final Block MARBLE_SLAB          = register("marble_slab", 3f, 0, ST, SlabBlock::new);
    public static final Block MARBLE_STAIRS        = register("marble_stairs", 3f, 0, ST, s -> new StairsBlock(MARBLE.getDefaultState(), s));
    public static final Block STEEL_PLATE_SLAB     = register("steel_plate_slab", 6f, 0, M, SlabBlock::new);
    public static final Block STEEL_PLATE_STAIRS   = register("steel_plate_stairs", 6f, 0, M, s -> new StairsBlock(STEEL_PLATE.getDefaultState(), s));
    public static final Block PLAZA_GRANITE_SLAB   = register("plaza_granite_slab", 4f, 0, ST, SlabBlock::new);

    private static Block cube(String name, float hardness, int light, BlockSoundGroup sound) {
        return register(name, hardness, light, sound, Block::new);
    }

    private static Block register(String name, float hardness, int light, BlockSoundGroup sound,
                                  Function<AbstractBlock.Settings, Block> factory) {
        Identifier id = Identifier.of(MOD_ID, name);
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, id);
        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, id);

        AbstractBlock.Settings settings = AbstractBlock.Settings.create()
                .registryKey(blockKey)
                .strength(hardness, 10f)
                .sounds(sound)
                .requiresTool();
        if (light > 0) {
            settings = settings.luminance(state -> light);
        }

        Block block = factory.apply(settings);
        Registry.register(Registries.BLOCK, blockKey, block);

        BlockItem item = new BlockItem(block, new Item.Settings()
                .registryKey(itemKey)
                .useBlockPrefixedTranslationKey());
        Registry.register(Registries.ITEM, itemKey, item);

        ALL.add(block);
        return block;
    }

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM_GROUP, Identifier.of(MOD_ID, "main"),
            FabricItemGroup.builder()
                .displayName(Text.translatable("itemGroup.wtcblocks.main"))
                .icon(() -> new ItemStack(FACADE_PANEL))
                .entries((ctx, entries) -> ALL.forEach(entries::add))
                .build());

        // /buildwtc : башни-близнецы, площадь, сфера, антенна и смотровая площадка.
        // Для серверов добавьте .requires(...) с проверкой прав оператора.
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("buildwtc").executes(ctx -> {
                var source = ctx.getSource();
                BlockPos origin = BlockPos.ofFloored(source.getPosition());
                int placed = WtcBuilder.build(source.getWorld(), origin);
                if (placed < 0) {
                    source.sendError(Text.literal("Слишком мало места по высоте — выберите место пониже."));
                    return 0;
                }
                source.sendFeedback(() -> Text.literal("World Trade Center построен: " + placed + " блоков."), true);
                return 1;
            })));
    }
}
