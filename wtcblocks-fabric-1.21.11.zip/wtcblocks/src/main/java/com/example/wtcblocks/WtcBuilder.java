package com.example.wtcblocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ConnectingBlock;
import net.minecraft.block.LadderBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import static com.example.wtcblocks.WtcBlocks.*;

/**
 * Две башни 32x32 (масштаб 1:2), площадь с гранитом и бронзовой сферой.
 * Левая (X-) башня: антенна на крыше. Правая (X+) башня: смотровая площадка,
 * стеклянный павильон и лестница-стремянка из лобби на крышу.
 */
public final class WtcBuilder {
    private static final int S = 32;
    private static final int FLOORS = 110;
    private static final int OFFSET = 27;
    private static final int ANT_MAX = 55;
    private static final int LADDER_X = 16;
    private static final int LADDER_Z = 30;

    private WtcBuilder() {}

    private static boolean inside(int x, int z) {
        if (x < 0 || z < 0 || x >= S || z >= S) return false;
        return Math.min(x, S - 1 - x) + Math.min(z, S - 1 - z) >= 3;
    }

    private static boolean perimeter(int x, int z) {
        return inside(x, z) && !(inside(x + 1, z) && inside(x - 1, z) && inside(x, z + 1) && inside(x, z - 1));
    }

    private static boolean corner(int x, int z) {
        return Math.min(x, S - 1 - x) <= 3 && Math.min(z, S - 1 - z) <= 3;
    }

    private static int[] bandStarts(int h) {
        int[] k = {6, 40, 74, 107};
        int[] r = new int[4];
        for (int i = 0; i < 4; i++) {
            r[i] = Math.max(10, Math.min(((int) (k[i] * h / 220.0)) * 2, h - 6));
        }
        return r;
    }

    private static boolean isBand(int h, int[] bs) {
        for (int s : bs) if (h >= s && h < s + 4) return true;
        return false;
    }

    /** @return число поставленных блоков или -1, если не хватает высоты */
    public static int build(ServerWorld w, BlockPos o) {
        int topEx = w.getBottomY() + w.getHeight();
        int avail = topEx - o.getY() - 6;
        if (avail < 60) return -1;
        int height = Math.min(FLOORS * 2, (int) (avail * 220 / 275.0));
        height &= ~1;
        int antLen = Math.min(ANT_MAX, avail - height - 2);

        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        int n = 0;

        int xa = ox - OFFSET - S / 2 - 8, xb = ox + OFFSET + S / 2 + 8;
        int za = oz - S / 2 - 8, zb = oz + S / 2 + 22;
        for (int x = xa; x <= xb; x++) {
            for (int z = za; z <= zb; z++) {
                n += set(w, x, oy - 1, z, PLAZA_GRANITE.getDefaultState());
            }
        }

        n += tower(w, ox - OFFSET - S / 2, oz - S / 2, oy, height, antLen, true);
        n += tower(w, ox + OFFSET - S / 2, oz - S / 2, oy, height, 0, false);
        n += sphere(w, ox, oy + 4, oz + 14);
        return n;
    }

    private static int sphere(ServerWorld w, int cx, int cy, int cz) {
        int n = 0;
        for (int dx = -4; dx <= 4; dx++)
            for (int dy = -4; dy <= 4; dy++)
                for (int dz = -4; dz <= 4; dz++)
                    if (dx * dx + dy * dy + dz * dz <= 17)
                        n += set(w, cx + dx, cy + dy, cz + dz, BRONZE_SPHERE_BLOCK.getDefaultState());
        return n;
    }

    private static BlockState ladder() {
        return Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.NORTH);
    }

    private static int tower(ServerWorld w, int x0, int z0, int y0, int height, int antLen, boolean north) {
        int n = 0;
        int entranceX = north ? S - 1 : 0;
        int[] bs = bandStarts(height);
        int yr = y0 + height;

        for (int x = 0; x < S; x++) {
            for (int z = 0; z < S; z++) {
                if (!inside(x, z)) continue;
                boolean per = perimeter(x, z);
                int gx = x0 + x, gz = z0 + z;
                boolean ladderCell = !north && x == LADDER_X && z == LADDER_Z;

                n += set(w, gx, y0 - 1, gz, MARBLE.getDefaultState());

                for (int h = 0; h < height; h++) {
                    BlockState st;
                    if (ladderCell) {
                        st = ladder();
                    } else if (per) {
                        if (x == entranceX && z >= 14 && z <= 17 && h < 4) st = Blocks.AIR.getDefaultState();
                        else st = pick(x, z, h, height, bs);
                    } else {
                        st = interior(x, z, h, bs);
                    }
                    if (st != null) n += set(w, gx, y0 + h, gz, st);
                }

                if (north) {
                    n += set(w, gx, yr, gz, ROOF_BLOCK.getDefaultState());
                    if (per) n += set(w, gx, yr + 1, gz, ROOF_BLOCK.getDefaultState());
                } else if (ladderCell) {
                    n += set(w, gx, yr, gz, ladder());
                    n += set(w, gx, yr + 1, gz, ladder());
                } else {
                    boolean pav = x >= 11 && x <= 20 && z >= 11 && z <= 20;
                    Block floor = per ? DARK_STEEL : (pav ? MARBLE : OBSERVATION_FLOOR);
                    n += set(w, gx, yr, gz, floor.getDefaultState());

                    if (per) {
                        if (x == LADDER_X && z == S - 1) {
                            n += set(w, gx, yr + 1, gz, STEEL_PLATE.getDefaultState());
                        } else {
                            n += set(w, gx, yr + 1, gz, STEEL_PLATE_SLAB.getDefaultState());
                            BlockState pane = Blocks.GLASS_PANE.getDefaultState()
                                    .with(ConnectingBlock.NORTH, perimeter(x, z - 1))
                                    .with(ConnectingBlock.SOUTH, perimeter(x, z + 1))
                                    .with(ConnectingBlock.EAST, perimeter(x + 1, z))
                                    .with(ConnectingBlock.WEST, perimeter(x - 1, z));
                            n += set(w, gx, yr + 2, gz, pane);
                            n += set(w, gx, yr + 3, gz, pane);
                        }
                    }
                    if (pav) {
                        boolean wall = x == 11 || x == 20 || z == 11 || z == 20;
                        if (wall) {
                            boolean door = z == 11 && (x == 15 || x == 16);
                            for (int dy = 1; dy <= 3; dy++) {
                                if (!(door && dy <= 2)) n += set(w, gx, yr + dy, gz, SKY_LOBBY_WINDOW.getDefaultState());
                            }
                        }
                        n += set(w, gx, yr + 4, gz, DARK_MARBLE.getDefaultState());
                        if ((x == 13 || x == 18) && (z == 13 || z == 18)) {
                            n += set(w, gx, yr + 3, gz, OFFICE_LIGHT.getDefaultState());
                        }
                    }
                }
            }
        }

        if (north) {
            if (antLen >= 12) n += antenna(w, x0 + 16, z0 + 16, yr + 1, antLen);
        } else {
            int[][] posts = {{8, 8}, {23, 8}, {8, 23}, {23, 23}};
            for (int[] p : posts) {
                n += set(w, x0 + p[0], yr + 1, z0 + p[1], STEEL_BEAM.getDefaultState());
                n += set(w, x0 + p[0], yr + 2, z0 + p[1], STEEL_BEAM.getDefaultState());
                n += set(w, x0 + p[0], yr + 3, z0 + p[1], OFFICE_LIGHT.getDefaultState());
            }
        }
        return n;
    }

    private static BlockState interior(int x, int z, int h, int[] bs) {
        if (h < 8) {
            if (x >= 14 && x <= 17 && z >= 14 && z <= 17) {
                boolean edge = x == 14 || x == 17 || z == 14 || z == 17;
                return ((edge && h < 2) ? ELEVATOR_DOOR : DARK_STEEL).getDefaultState();
            }
            if (h == 7 && x % 4 == 2 && z % 4 == 2) return OFFICE_LIGHT.getDefaultState();
            return Blocks.AIR.getDefaultState();
        }
        if (h == 8) return CEILING_TILE.getDefaultState();
        for (int s : bs) if (h == s) return CONCRETE_FLOOR.getDefaultState();
        return null;
    }

    private static BlockState pick(int x, int z, int h, int height, int[] bs) {
        Block b;
        if (corner(x, z)) {
            b = (h < 8) ? TRIDENT_COLUMN : CORNER_COLUMN;
        } else if (h < 8) {
            if (h == 7) b = TRIDENT_COLUMN;
            else if (((x + z) & 1) == 0) b = LOBBY_COLUMN;
            else b = (h == 0) ? DARK_MARBLE : SKY_LOBBY_WINDOW;
        } else if (isBand(h, bs)) {
            b = ((x + z) % 4 == 0) ? STEEL_PLATE : MECHANICAL_BAND;
        } else if (h % 2 == 0) {
            if (h < 24) b = FACADE_PANEL_DARK;
            else if (h >= height - 8) b = FACADE_PANEL_LIGHT;
            else b = FACADE_PANEL;
        } else {
            if ((x + z) % 4 == 0) b = STEEL_BEAM;
            else b = (h > height * 0.85) ? MIRROR_GLASS : WINDOW_PANEL;
        }
        return b.getDefaultState();
    }

    private static boolean ring(int dx, int dz, int r) {
        return Math.max(Math.abs(dx), Math.abs(dz)) == r;
    }

    private static boolean conn(int dx, int dz, int r) {
        return ring(dx, dz, r) || (dx == 0 && dz == 0);
    }

    /** Решётчатая мачта, сужающаяся кверху, с красными огнями на вершине. */
    private static int antenna(ServerWorld w, int cx, int cz, int baseY, int len) {
        int n = 0;
        for (int a = 0; a < len; a++) {
            int y = baseY + a;
            int r = a < len * 0.25 ? 2 : (a < len * 0.55 ? 1 : 0);

            Block c = (a == len - 1) ? ANTENNA_BEACON : (a % 6 == 5 ? DARK_STEEL : ANTENNA_SEGMENT);
            n += set(w, cx, y, cz, c.getDefaultState());

            if (r >= 1) {
                Block cb = (a == 0 || a == (int) (len * 0.25)) ? ANTENNA_BEACON : STEEL_BEAM;
                for (int sx = -1; sx <= 1; sx += 2)
                    for (int sz = -1; sz <= 1; sz += 2)
                        n += set(w, cx + sx * r, y, cz + sz * r, cb.getDefaultState());

                if (a % 4 == 0) {
                    for (int d = -r + 1; d <= r - 1; d++) {
                        n += bar(w, cx, cz, y, d, -r, r);
                        n += bar(w, cx, cz, y, d, r, r);
                        n += bar(w, cx, cz, y, -r, d, r);
                        n += bar(w, cx, cz, y, r, d, r);
                    }
                }
            }
        }
        return n;
    }

    private static int bar(ServerWorld w, int cx, int cz, int y, int dx, int dz, int r) {
        BlockState st = Blocks.IRON_BARS.getDefaultState()
                .with(ConnectingBlock.NORTH, conn(dx, dz - 1, r))
                .with(ConnectingBlock.SOUTH, conn(dx, dz + 1, r))
                .with(ConnectingBlock.EAST, conn(dx + 1, dz, r))
                .with(ConnectingBlock.WEST, conn(dx - 1, dz, r));
        return set(w, cx + dx, y, cz + dz, st);
    }

    private static int set(ServerWorld w, int x, int y, int z, BlockState state) {
        w.setBlockState(new BlockPos(x, y, z), state, Block.NOTIFY_LISTENERS);
        return 1;
    }
}
